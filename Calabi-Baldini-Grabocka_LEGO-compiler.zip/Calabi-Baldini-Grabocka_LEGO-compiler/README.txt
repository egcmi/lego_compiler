Welcome to LEGO compiler
A compiler to play with our beloved LEGO bricks!
You can find the source code in the folder "src/"
to compile: `make`
to run: `make run` or `./lego.out`
to clean (after usage): `make clean`
We included some sample input containing all the possible commands in the file "test/example.txt"
You can use it for inspiration or run it: `make run < test/example.txt`
Enjoy!

Project for Prof. Artale Alessandro
Course Formal Languages and Compilers
A.Y. 2017-2018
BSc in Computer Science
Faculty of Computer Science
Free University of Bolzano - Bozen

Developed using Lex, YACC and C
By the students:
Emanuela Giovanna Calabi
Giulia Baldini
Mikel Grabocka